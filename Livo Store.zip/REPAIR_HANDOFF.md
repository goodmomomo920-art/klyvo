## What failed

The migration `supabase/migrations/20261018000000_analytics_carts_loyalty.sql` failed with:

`ERROR: 42710: trigger "trigger_carts_updated_at" for relation "carts" already exists`

That is a duplicate-trigger error, not a general schema failure. It points at the exact statement that aborted:

```sql
CREATE TRIGGER trigger_carts_updated_at
  BEFORE UPDATE ON public.carts
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();
```

That statement is plain `CREATE TRIGGER`, not `CREATE TRIGGER IF NOT EXISTS`, so if the trigger already existed when that line ran, the migration stops there.

## Likely state of the migration

The migration file itself is mostly idempotent:

- Tables use `CREATE TABLE IF NOT EXISTS`
- Indexes use `CREATE INDEX IF NOT EXISTS`
- Functions use `CREATE OR REPLACE FUNCTION`
- RLS uses `ALTER TABLE ... ENABLE ROW LEVEL SECURITY` plus `DROP POLICY IF EXISTS` / `CREATE POLICY`

The one non-idempotent piece is the three plain `CREATE TRIGGER` statements for the `updated_at` triggers. The carts trigger is the most likely failure point because of the reported error, but the same pattern applies to `trigger_abandoned_cart_settings_updated_at` and `trigger_loyalty_settings_updated_at`.

So the migration may be partially applied. Most likely:

- tables exist
- indexes exist
- functions exist
- RLS/policies/grants may already be applied
- the carts trigger already exists, possibly correctly, possibly not

I did not assume the trigger is correct just because it exists. A trigger can exist with the wrong timing, the wrong function, or a disabled state, and I did not want to blindly drop it.

## What I created

### `supabase/migrations/20261018000000_recovery_probe.sql`

A read-only probe to run first. It reports:

- which of the five new tables exist
- which of those tables are still missing
- which indexes exist
- which migration functions exist and whether they are security definer
- the current definition references for the three `updated_at` triggers
- a focused breakdown of `trigger_carts_updated_at` on `carts`
- whether `handle_updated_at()` exists in `public`
- a short “which step likely failed” summary

Run this before applying the recovery migration. If the carts trigger already exists, this script will show you what it currently points to and whether it is enabled.

### `supabase/migrations/20261018000000_recovery_add_missing_objects.sql`

The actual recovery migration. It is written to be safe to run more than once and conservative about existing objects. In order it:

1. prints a diagnostic snapshot
2. creates only missing tables with `CREATE TABLE IF NOT EXISTS`
3. creates only missing indexes with `CREATE INDEX IF NOT EXISTS`
4. creates the settings-table `updated_at` triggers only if they are missing
5. handles the carts trigger by inspecting `pg_trigger` first and only creating it if it is missing, otherwise raising a notice telling you to inspect the existing trigger before taking further action
6. re-runs all migration functions with `CREATE OR REPLACE FUNCTION`
7. re-applies table comments
8. re-applies RLS enablement, policy drops/creates, and grants using the same object names as the original migration

It intentionally does not drop existing triggers, tables, indexes, policies, functions, or data.

## What this does not do

- It does not execute SQL against the remote database.
- It does not blindly drop or recreate `trigger_carts_updated_at`.
- It does not guess the behavior of `handle_updated_at()` if that function is missing or lives outside `public`.

## Prerequisites and caveats

- The carts trigger references `public.handle_updated_at()`. That function must exist in `public` before the trigger can succeed. If it is missing, the recovery migration will not invent its behavior.
- If the probe shows that `trigger_carts_updated_at` already exists but points at the wrong function or the wrong timing, the correct fix is a targeted manual change to that trigger, not a blanket rerun of the original migration.
- The recovery migration is safe to apply only after you have reviewed the probe output for the carts trigger.

## Files delivered

- `supabase/migrations/20261018000000_recovery_probe.sql`
- `supabase/migrations/20261018000000_recovery_add_missing_objects.sql`
- `REPAIR_HANDOFF.md`

## Checks I ran

- `npx tsc --noEmit` — pass
- `npm run lint` — pass

## Remaining limitations

- I could not run the probe or recovery SQL against the actual Supabase project from here, so I cannot confirm which objects already exist in the remote database.
- I cannot confirm whether the original migration was applied up to the carts trigger or stopped earlier.
- If the probe shows the carts trigger is already correct, the recovery migration is still safe, but it may be largely a no-op for that object.
- If the probe shows something unexpected, stop and inspect before applying the recovery migration.
