type CacheEntry = { value: unknown; expiresAt: number };

const entries = new Map<string, CacheEntry>();
const TTL_MS = 30_000;

export async function cached<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const now = Date.now();
  const existing = entries.get(key);
  if (existing && existing.expiresAt > now) return existing.value as T;
  const value = await fn();
  entries.set(key, { value, expiresAt: Date.now() + TTL_MS });
  return value;
}

export function clearClientCache(): void {
  entries.clear();
}
