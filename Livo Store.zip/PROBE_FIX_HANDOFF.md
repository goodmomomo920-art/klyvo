## What broke in the probe SQL

The failing query was this one:

```sql
SELECT expected.indexname, expected.tablename
FROM unnest(ARRAY[
  ('carts_store_activity_idx', 'carts'),
  ('carts_store_status_idx', 'carts'),
  ('loyalty_ledger_customer_created_idx', 'loyalty_ledger'),
  ('loyalty_ledger_store_created_idx', 'loyalty_ledger'),
  ('loyalty_ledger_order_idx', 'loyalty_ledger')
]::text[]) AS expected(indexname, tablename)
WHERE NOT EXISTS (
  SELECT 1
  FROM pg_indexes
  WHERE schemaname = 'public'
    AND indexname = expected.indexname
)
ORDER BY expected.indexname;
```

The bug was the cast:

```sql
]::text[]
```

That array constant contained 2-element row literals, but the cast forced it into a plain `text[]`. PostgreSQL then saw the alias `expected(indexname, tablename)` trying to define a two-column range table, while only one column was available from the cast array. That is what produced:

`ERROR: 42P10: table "expected" has 1 columns available but 2 columns specified`

The same issue was not reached earlier in the run because the other `unnest(...)` calls used single-column arrays and did not alias multiple columns.

## Fix

Change the cast from `::text[]` to a row-typed array:

```sql
]::record[]) AS expected(indexname, tablename)
```

I also removed a stray duplicated section header line that was left in from a previous edit pass, and kept everything else identical.

## Status of the probe file

The file is now strictly read-only. It contains no `CREATE`, `ALTER`, `DROP`, `INSERT`, `UPDATE`, `DELETE`, or other mutating statements.

The only transaction control left in the file is commented out:

```sql
-- BEGIN;  -- uncomment only if your client supports multi-statement read-only transactions
...
-- COMMIT;  -- uncomment only if you began a read-only transaction above
```

If Supabase SQL Editor still rejects the file as a whole, paste only the `SELECT` statements, skipping the commented `BEGIN`/`COMMIT` lines. That is still read-only.

## What each section reports

1. `== tables ==`
   Lists which of the five migration tables already exist in `public`.

2. `== missing tables expected by the original migration ==`
   Lists which of those five tables are still missing.

3. `== indexes ==`
   Lists which of the five migration indexes already exist.

4. `== missing indexes expected by the original migration ==`
   Lists which indexes are still missing.

5. `== functions owned by this migration ==`
   Lists each migration function that exists, with its kind, security-definer status, return type class, and volatility. Use this to confirm the functions exist before relying on the recovery migration.

6. `== missing functions expected by the original migration ==`
   Lists which expected functions are still missing.

7. `== triggers on carts / abandoned_cart_settings / loyalty_settings ==`
   Shows the three `updated_at` triggers the original migration tried to create, if they exist. Pay attention to the `function_call` column. If `trigger_carts_updated_at` exists but points at something other than `public.handle_updated_at()`, or if `timing` is not `BEFORE`, that trigger needs manual inspection before anything else is applied.

8. `== carts trigger detailed inspection ==`
   A focused breakdown of `trigger_carts_updated_at` on `public.carts`, if it exists. This is the most likely “already exists” object from the reported failure.

9. `== helpful: which table already has a BEFORE UPDATE updated_at trigger ==`
   Lists any table in `public` that already has a `BEFORE` trigger whose name looks like a generic `updated_at` trigger. Helpful if you suspect an updated-at trigger was applied under a different name.

10. `== handle_updated_at availability ==`
    Shows whether `handle_updated_at()` exists in the catalog and where. If it is missing or not in `public`, the carts trigger cannot reference it correctly.

11. `== abstracted answer: which migration step likely failed ==`
    A short summary of the two most important facts: whether `public.carts` exists, and whether `trigger_carts_updated_at` already exists.

## How to interpret the likely failure

- If `public.carts` exists but `trigger_carts_updated_at` does not, the migration probably failed earlier than the trigger statement and the recovery script should create the trigger.
- If `public.carts` exists and `trigger_carts_updated_at` already exists, the reported `42710` error matches this being the statement that aborted a partial run. In that case, inspect the trigger’s current function and timing before applying anything that touches it.
- If `handle_updated_at()` is not present in `public`, the carts trigger cannot be created to point at it, and the recovery migration should not pretend otherwise.

## Files touched

- `supabase/migrations/20261018000000_recovery_probe.sql` — fixed
- `PROBE_FIX_HANDOFF.md` — this note

## Checks I ran

- `npx tsc --noEmit` — pass
- `npm run lint` — pass
