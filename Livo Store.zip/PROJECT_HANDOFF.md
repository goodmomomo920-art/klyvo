## Overview

Klyvo (codebase name: livo-store) is a merchant dashboard + public storefront for an Egyptian e-commerce SaaS. Auth is Supabase; most backend work is store-scoped Server Actions and SECURITY DEFINER Supabase RPCs.

---

## Stack (verified from `package.json` and `node_modules`)

- Framework: Next.js 16.4.0 (App Router, Turbopack)
- React: 19.3.0
- TypeScript: ^5
- Tailwind CSS: ^4 (`@tailwindcss/turbopack`)
- Supabase client: `@supabase/supabase-js` ^2.118.0, `@supabase/ssr` ^0.12.7
- Package manager: npm
- Tests: Node's built-in test runner (`npm test` -> `node --test tests/*.test.mjs`). Node ≥ 22.18 is required because the tests import the TypeScript modules directly with type stripping.

---

## Important structure

- `src/app/layout.tsx` — root layout
- `src/app/page.tsx` — marketing landing page
- `src/app/login/page.tsx`, `signup/page.tsx`, `forgot-password/page.tsx` — auth UI
- `src/app/auth/callback/route.ts` — auth exchange route
- `src/app/dashboard/layout.tsx` — server auth guard; `dynamic = 'force-dynamic'`
- `src/app/dashboard/page.tsx` — overview
- `src/app/dashboard/products/page.tsx` — product CRUD + variant management entry point
- `src/app/dashboard/orders/page.tsx` — orders list, statuses, details (shows variant label/SKU)
- `src/app/dashboard/customers/page.tsx` — customer directory
- `src/app/dashboard/settings/page.tsx` — store profile, regional, shipping defaults, delivery areas, payments
- `src/app/dashboard/appearance/page.tsx` — appearance editor, draft preview, publish
- `src/app/dashboard/reviews/page.tsx` — review moderation
- `src/app/dashboard/campaigns/page.tsx` — campaign CRUD, tracked links, measured performance
- `src/app/dashboard/coupons/page.tsx` — coupon list
- `src/app/dashboard/analytics/page.tsx`, `abandoned-carts/page.tsx`, `loyalty/page.tsx` — unchanged from the previous milestone
- `src/app/store/[slug]/layout.tsx` — public storefront; `dynamic = 'force-dynamic'`
- `src/app/store/[slug]/page.tsx` — storefront hero/sections/catalog
- `src/app/store/[slug]/product/[productId]/page.tsx` — variant selection, reviews
- `src/app/store/[slug]/cart/page.tsx`, `checkout/page.tsx`
- `src/lib/server/` — stores, products, variants, shipping, storeSettings, storefront, orders, customers, coupons, campaigns, reviews, appearance, analytics, cartLifecycle, loyalty, cartTokenHash
- `src/lib/` — `shipping.ts`, `variants.ts`, `appearance.ts`, `reviews.ts`, `campaigns.ts` (pure calculation/validation helpers shared by dashboard, storefront, and tests)
- `src/components/dashboard/` — shell, sidebar, top bar, product/variant/shipping/campaign modals
- `src/components/storefront/` — `StorefrontShell`, `ProductBrowser`, `ProductDetailView`, `CartView`, `CheckoutView`, `CartLifecycleSync`, `CampaignTracker`
- `tests/` — shipping, variants, appearance, reviews, campaigns tests (36 tests)

---

## Feature status

| Feature | Status | Notes |
|---|---|---|
| Marketing landing page, auth UI, callback | Done | Unchanged. |
| Dashboard auth guard, shell/sidebar | Done | New routes added to sidebar. |
| Store resolution / bootstrap | Done | Unchanged. |
| Products CRUD | Done | Extended with variant counts and derived-stock handling. |
| Product variants | Implemented, database migration pending | Options/values/variants CRUD, per-variant SKU/price/stock, store-scoped unique SKUs, storefront selection, variant-aware checkout, order-line snapshots. |
| Shipping & delivery settings | Implemented, database migration pending | 27 governorates, zones with fees/optional thresholds, store defaults, shared calculation, server-side fee resolution. No courier integration. |
| Store appearance customization | Implemented, database migration pending | Logo, colors, font allowlist, hero copy/image/CTA (EN/AR), homepage section toggles, draft + preview + publish, published-only public rendering. |
| Product reviews & ratings | Implemented, database migration pending | Star + written reviews, phone-hash dedupe, pending/published/rejected moderation, DB-proven verified-purchase badge, published-only aggregates. |
| Marketing campaigns | Implemented, database migration pending | Campaigns linked to existing coupons, schedule/status, optional featured products, tracked links, deduplicated visits, verified same-browser order attribution. No message delivery. |
| Orders list + status workflow | Done | Order details now include variant label and SKU. |
| Atomic merchant order creation RPC | Done | Not modified; still product-level stock (see limitations). |
| Customer directory | Done | Unchanged. |
| Coupon management | Done | Campaigns reuse this engine; no second discount system. |
| Store settings | Done | Shipping defaults remain here; delivery areas are a new panel. |
| Analytics / abandoned carts / loyalty | Partial | Depends on the unresolved `20261018000000` migration. |

---

## Migrations

Existing migrations (status UNKNOWN; owner must confirm):

- `20261016000000_secure_multi_tenant_foundation.sql` — stores, products, RLS.
- `20261016000001_orders_and_customers.sql` — orders, customers, order_items.
- `20261016000002_orders_customers_integrity_and_rpc.sql` — integrity triggers, `create_store_order`.
- `20261016000003_orders_customers_hardening.sql` — numeric bounds, locks.
- `20261016000004_store_settings.sql` — store settings + payment methods.
- `20261016000005_public_storefront_checkout.sql` — initial public storefront RPCs.
- `20261017000000_discount_coupons.sql` — coupons + usage audit.
- `20261018000000_analytics_carts_loyalty.sql` + `20261018000000_recovery_*` — **UNRESOLVED**. Do not edit, delete, rename, or assume applied. Nothing added in this milestone depends on these objects.

New migrations (NOT applied; do not apply automatically):

| File | Creates | Depends on |
|---|---|---|
| `20261019000000_product_variants.sql` | `product_options`, `product_option_values`, `product_variants`, `order_items.variant_id/variant_label`, SKU/combination/stock triggers | `20261016000000`, `20261016000001` |
| `20261019000001_shipping_zones.sql` | `shipping_zones` + RLS/constraints | `20261016000000` |
| `20261019000002_store_appearance.sql` | `store_appearance` (draft/published JSONB) + RLS | `20261016000000` |
| `20261019000003_product_reviews.sql` | `product_reviews`, `submit_public_product_review`, `get_public_product_reviews` | `20261016000000`, `20261016000001`, `20261017000000` (coupon-independent) |
| `20261019000004_marketing_campaigns.sql` | `marketing_campaigns`, `campaign_visits`, `campaign_orders`, `record_campaign_visit`, `record_campaign_order` | `20261016000000`, `20261016000001`, `20261017000000` |
| `20261019000005_storefront_rpc_extensions.sql` | Replaces `get_public_store`, `get_public_store_products`, `create_public_store_order` with variant/shipping/review/campaign-aware versions | `20261016000000`, `20261016000001`, `20261016000004`, `20261016000005`, `20261017000000`, and `20261019000000`–`20261019000004` |

Apply order: 0000 → 0001 → 0002 → 0003 → 0004 → 0005. `20261019000005` must be last; it drops/recreates the public RPC signatures used by the app.

### Manual review/apply steps

1. Review each new file for the target project; none has been executed against Supabase by the assistant.
2. Apply `20261019000000` through `20261019000004` in timestamp order in a staging project.
3. Verify the new tables/constraints exist, and run `SELECT * FROM pg_policies WHERE schemaname = 'public' AND tablename IN (...)` to confirm RLS policies.
4. Apply `20261019000005` last and confirm the three RPC function signatures match the app calls (`get_public_store(text)`, `get_public_store_products(text,int,int,text,text,uuid)`, `create_public_store_order(text,text,text,text,text,text,text,text,text,jsonb,text,uuid)`).
5. Smoke-test with two merchant accounts: cross-store variant edits, review moderation, campaign creation, and a public checkout selecting a shipping zone.
6. Only then apply to production. Do not apply the unresolved `20261018000000` migration as part of this milestone.

### Explicit dependencies / assumptions

- New migrations use `gen_random_uuid()`, `handle_updated_at()`, and the existing `stores` / `products` / `orders` / `order_items` / `customers` / `coupons` schema.
- `20261019000005` assumes `cleanup` objects from `20261016000005` exist (it replaces those functions) and that `20261019000001`/`0002` tables exist.
- No new code depends on `trigger_carts_updated_at`, analytics, carts, or loyalty objects.
- No secrets, `.env.local` changes, or remote SQL execution were performed.

---

## Confirmed product decisions

- Arabic product name required; English product name optional.
- Order numbers are `ORD-YYYYMMDD-[RANDOM]`, generated server-side.
- Product images should move to Supabase Storage later; appearance logo URLs are validated `http(s)` only.
- Strict multi-tenant isolation via `store_id` + RLS; all new tables are RLS-enabled and store-filtered in code.
- Archived products cannot be ordered; manual custom line items still allowed.
- Non-COD payment selection does not auto-mark an order Paid.
- Stock is an availability value, not a reservation ledger. Checkout validates but does not decrement stock (existing behavior preserved).

---

## Verification (this milestone)

Commands run in the workspace:

- `npm test` — **36 tests, 36 pass, 0 fail** (`tests/shipping.test.mjs`, `variants.test.mjs`, `appearance.test.mjs`, `reviews.test.mjs`, `campaigns.test.mjs`).
- `npx tsc --noEmit` — exit 0.
- `npx eslint .` — exit 0.
- `npm run build` — exit 0 (Next.js 16.4.0, Turbopack). Route manifest includes `/dashboard/appearance`, `/dashboard/reviews`, `/dashboard/campaigns`, `/store/[slug]`, `/store/[slug]/product/[productId]`, cart, and checkout.

Not verified: runtime behavior against Supabase, RLS enforcement, and the actual migration SQL. They require the migrations above to be reviewed/applied and two authenticated stores. Do not treat the feature-backed pages as "working with data" until then.

---

## Known limitations / incomplete integrations

- **Database setup is pending.** Variants, shipping zones, appearance, reviews, and campaigns pages return actionable errors when their tables are missing (e.g. "Apply migration … in Supabase first"), but they cannot load or save data until applied.
- **Non-decrementing stock.** Checkout rejects quantities above current variant/product stock, but concurrent orders can oversell because stock is not decremented. This matches the pre-existing catalog behavior; changing it would require a restock flow on cancellation.
- **Variant save is not one SQL transaction.** The Server Action performs option/value upserts, deletions, and variant upserts as separate Supabase calls (the JS client has no multi-statement transaction). A failure midway can leave a partially saved option set; re-saving the modal reconciles it. Wrapping this in one RPC is the recommended follow-up.
- **Logo/banner assets are URL-based.** The appearance editor accepts validated `http(s)` image URLs; it does not upload files to storage yet.
- **Merchant manual orders** (`create_store_order` used by the dashboard) remain product-level and do not require a variant selection. Only public storefront checkout is variant-aware.
- **Abandoned-cart recovery** restores product-level quantities only; variant selections are not stored in the cart-lifecycle payload, so recovery cannot re-add variant products. The analytics/carts migration is also still unresolved.
- **Review identity** is a hashed phone number per store/product; a reviewer using a different phone can submit again. Verified purchase requires a `Delivered` order containing the product and the same normalized phone — no identity is invented.
- **Campaign attribution** is same-browser (localStorage visitor/campaign context) and last-touch. Orders are attributed only when reported within 30 minutes and inside the campaign window; revenue is copied from `orders.total`. No email/SMS/WhatsApp/ads delivery exists, and product selection is organizational only (the coupon stays store-wide).
- **Appearance preview** is dashboard-only; the public storefront reads only the published snapshot. Fonts are limited to system stacks, so no external font is fetched.
- The dev-server runtime state on this machine is UNKNOWN; no persistent dev server was run for this report.
